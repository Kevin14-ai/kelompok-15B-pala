package com.kelompok15b.falambar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Menu Utama aplikasi, berisi dua pilihan sesuai use case diagram BAB III:
 * (1) Deteksi Kematangan Buah Pala, (2) Informasi Aplikasi.
 */
public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button btnDeteksi = findViewById(R.id.btnMenuDeteksi);
        Button btnInfo = findViewById(R.id.btnMenuInfo);

        btnDeteksi.setOnClickListener(v ->
                startActivity(new Intent(MenuActivity.this, DetectionActivity.class)));

        btnInfo.setOnClickListener(v ->
                startActivity(new Intent(MenuActivity.this, InfoActivity.class)));
    }
}
