package com.kelompok15b.falambar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Halaman deteksi kematangan buah pala. Menjalankan dua model (YOLOv10 dan YOLOv12)
 * secara berurutan pada citra yang sama, lalu menampilkan hasil keduanya berdampingan
 * agar pengguna dapat membandingkan performa kedua model secara langsung.
 *
 * Perbaikan pada versi ini:
 * - Kamera menyimpan foto resolusi penuh (via FileProvider), bukan thumbnail resolusi
 *   rendah yang sebelumnya menyebabkan hasil deteksi kurang akurat.
 * - Foto dari galeri maupun kamera dikoreksi orientasinya berdasarkan data EXIF, karena
 *   file gambar sering tersimpan "miring" secara data mentah sebelum dikoreksi rotasinya.
 */
public class DetectionActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_IMAGE_CAPTURE = 101;
    private static final int REQUEST_IMAGE_GALLERY = 102;

    private ImageView imagePreview;
    private TextView tvPlaceholder;
    private TextView resultV10Label, resultV10Confidence, resultV10Time;
    private TextView resultV12Label, resultV12Confidence, resultV12Time;
    private Bitmap currentBitmap;
    private Uri pendingCameraUri;

    private YoloDetector detectorV10;
    private YoloDetector detectorV12;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detection);

        imagePreview = findViewById(R.id.imagePreview);
        tvPlaceholder = findViewById(R.id.tvPlaceholder);
        resultV10Label = findViewById(R.id.resultV10Label);
        resultV10Confidence = findViewById(R.id.resultV10Confidence);
        resultV10Time = findViewById(R.id.resultV10Time);
        resultV12Label = findViewById(R.id.resultV12Label);
        resultV12Confidence = findViewById(R.id.resultV12Confidence);
        resultV12Time = findViewById(R.id.resultV12Time);

        Button btnCamera = findViewById(R.id.btnCamera);
        Button btnGallery = findViewById(R.id.btnGallery);
        Button btnAmbilFotoBaru = findViewById(R.id.btnAmbilFotoBaru);
        Button btnSimpanHasil = findViewById(R.id.btnSimpanHasil);

        try {
            detectorV10 = new YoloDetector(this, "yolov10_pala.tflite", "labels.txt", true);
            detectorV12 = new YoloDetector(this, "yolov12_pala.tflite", "labels.txt", false);
        } catch (IOException e) {
            Toast.makeText(this, "Gagal memuat model: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        btnCamera.setOnClickListener(v -> openCamera());
        btnGallery.setOnClickListener(v -> openGallery());
        btnAmbilFotoBaru.setOnClickListener(v -> resetToEmptyState());

        btnSimpanHasil.setOnClickListener(v -> {
            if (currentBitmap == null) {
                Toast.makeText(this, "Belum ada hasil untuk disimpan", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Fitur simpan hasil akan segera tersedia", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetToEmptyState() {
        currentBitmap = null;
        imagePreview.setImageDrawable(null);
        tvPlaceholder.setVisibility(android.view.View.VISIBLE);
        resultV10Label.setText("-");
        resultV10Confidence.setText("-");
        resultV10Time.setText("-");
        resultV12Label.setText("-");
        resultV12Confidence.setText("-");
        resultV12Time.setText("-");
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
            return;
        }
        try {
            File photoFile = File.createTempFile(
                    "PALA_" + System.currentTimeMillis(), ".jpg",
                    getExternalFilesDir(Environment.DIRECTORY_PICTURES));
            pendingCameraUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", photoFile);

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
            }
        } catch (IOException e) {
            Toast.makeText(this, "Gagal menyiapkan berkas foto: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_IMAGE_GALLERY);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else if (requestCode == REQUEST_CAMERA_PERMISSION) {
            Toast.makeText(this, "Izin kamera diperlukan untuk mengambil foto", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;

        Bitmap bitmap = null;
        try {
            if (requestCode == REQUEST_IMAGE_CAPTURE && pendingCameraUri != null) {
                bitmap = loadRotatedBitmap(pendingCameraUri);
            } else if (requestCode == REQUEST_IMAGE_GALLERY && data != null && data.getData() != null) {
                bitmap = loadRotatedBitmap(data.getData());
            }
        } catch (IOException e) {
            Toast.makeText(this, "Gagal memuat gambar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        if (bitmap != null) {
            currentBitmap = bitmap;
            imagePreview.setImageBitmap(bitmap);
            tvPlaceholder.setVisibility(android.view.View.GONE);
            runDetection(bitmap);
        }
    }

    /**
     * Memuat bitmap dari Uri (baik hasil kamera maupun galeri) dan mengoreksi
     * orientasinya berdasarkan metadata EXIF, agar gambar yang diproses model
     * selalu tegak lurus sesuai tampilan aslinya.
     */
    private Bitmap loadRotatedBitmap(Uri uri) throws IOException {
        Bitmap bitmap;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(input);
        }
        if (bitmap == null) {
            throw new IOException("Gambar tidak dapat dibaca");
        }

        int rotationDegrees = 0;
        try (InputStream exifInput = getContentResolver().openInputStream(uri)) {
            if (exifInput != null) {
                ExifInterface exif = new ExifInterface(exifInput);
                int orientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90:
                        rotationDegrees = 90;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_180:
                        rotationDegrees = 180;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_270:
                        rotationDegrees = 270;
                        break;
                    default:
                        rotationDegrees = 0;
                }
            }
        }

        if (rotationDegrees != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(rotationDegrees);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        }
        return bitmap;
    }

    private void runDetection(Bitmap bitmap) {
        if (detectorV10 == null || detectorV12 == null) {
            Toast.makeText(this, "Model belum siap", Toast.LENGTH_SHORT).show();
            return;
        }

        List<Detection> resultsV10 = detectorV10.detect(bitmap);
        displayResult(resultsV10, resultV10Label, resultV10Confidence, resultV10Time, detectorV10.getLastInferenceTimeMs());

        List<Detection> resultsV12 = detectorV12.detect(bitmap);
        displayResult(resultsV12, resultV12Label, resultV12Confidence, resultV12Time, detectorV12.getLastInferenceTimeMs());
    }

    private void displayResult(List<Detection> results, TextView labelView, TextView confView, TextView timeView, long timeMs) {
        if (results.isEmpty()) {
            labelView.setText("Pala tidak terdeteksi");
            confView.setText("-");
        } else {
            Detection best = results.get(0);
            String labelDisplay = best.label.equalsIgnoreCase("mentah") ? "Belum Masak" : "Matang";
            labelView.setText(labelDisplay);
            confView.setText(String.format("%.1f%% confidence", best.confidence * 100));
        }
        timeView.setText("Waktu inferensi: " + timeMs + " ms");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (detectorV10 != null) detectorV10.close();
        if (detectorV12 != null) detectorV12.close();
    }
}
