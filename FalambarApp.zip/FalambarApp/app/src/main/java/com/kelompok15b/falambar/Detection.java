package com.kelompok15b.falambar;

import android.graphics.RectF;

/**
 * Merepresentasikan satu hasil deteksi: label kelas, tingkat keyakinan (confidence),
 * dan koordinat bounding box pada citra asli.
 */
public class Detection {
    public final String label;
    public final float confidence;
    public final RectF box;

    public Detection(String label, float confidence, RectF box) {
        this.label = label;
        this.confidence = confidence;
        this.box = box;
    }
}
