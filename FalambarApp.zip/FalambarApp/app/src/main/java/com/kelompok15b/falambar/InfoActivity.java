package com.kelompok15b.falambar;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Halaman Informasi Aplikasi: deskripsi singkat aplikasi dan identitas pengembang
 * (Kelompok 15B), sesuai rancangan pada BAB III.
 */
public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }
}
