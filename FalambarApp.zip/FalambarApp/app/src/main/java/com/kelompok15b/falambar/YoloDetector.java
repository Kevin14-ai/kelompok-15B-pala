package com.kelompok15b.falambar;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.Log;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Kelas pembungkus (wrapper) untuk memuat model YOLO (.tflite) dan menjalankan
 * inferensi deteksi objek pada citra masukan.
 *
 * PERBAIKAN PENTING pada versi ini: bentuk (shape) tensor keluaran model TIDAK
 * lagi di-hardcode/ditebak, melainkan dibaca langsung dari model saat runtime
 * (interpreter.getOutputTensor(0).shape()). Ini menghindari kesalahan parsing
 * yang terjadi apabila proses konversi/export model menghasilkan urutan dimensi
 * yang berbeda dari dugaan awal.
 *
 * Mendukung dua format keluaran model yang berbeda:
 * - YOLOv10 (end-to-end): keluaran sudah melalui NMS bawaan model, bentuk (1, N, 6)
 *   berisi [x1, y1, x2, y2, confidence, class_id] per baris.
 * - YOLOv12 (format standar): keluaran mentah, bisa berbentuk channel-first (1, 6, N)
 *   atau channel-last (1, N, 6) tergantung hasil konversi, memerlukan penerapan
 *   confidence threshold dan Non-Maximum Suppression (NMS) secara manual.
 */
public class YoloDetector {

    private static final String TAG = "YoloDetector";
    public static final int INPUT_SIZE = 640;
    private static final float CONF_THRESHOLD = 0.2f;
    private static final float IOU_THRESHOLD = 0.45f;

    private final Interpreter interpreter;
    private final List<String> labels;
    private final boolean isEndToEnd;
    private long lastInferenceTimeMs = 0;

    public YoloDetector(Context context, String modelFileName, String labelFileName, boolean isEndToEnd) throws IOException {
        MappedByteBuffer modelBuffer = loadModelFile(context, modelFileName);
        Interpreter.Options options = new Interpreter.Options();
        options.setNumThreads(4);
        this.interpreter = new Interpreter(modelBuffer, options);
        this.labels = loadLabelsFile(context, labelFileName);
        this.isEndToEnd = isEndToEnd;

        int[] outputShape = interpreter.getOutputTensor(0).shape();
        Log.d(TAG, modelFileName + " - output shape: " + Arrays.toString(outputShape));
        Log.d(TAG, modelFileName + " - urutan label terbaca: " + labels);
    }

    private MappedByteBuffer loadModelFile(Context context, String modelFileName) throws IOException {
        AssetFileDescriptor fileDescriptor = context.getAssets().openFd(modelFileName);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    private List<String> loadLabelsFile(Context context, String labelFileName) throws IOException {
        List<String> labelList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(context.getAssets().open(labelFileName)));
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty()) {
                labelList.add(line);
            }
        }
        reader.close();
        return labelList;
    }

    public long getLastInferenceTimeMs() {
        return lastInferenceTimeMs;
    }

    public List<Detection> detect(Bitmap bitmap) {
        long startTime = SystemClock.elapsedRealtime();

        Bitmap resized = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true);
        ByteBuffer inputBuffer = bitmapToByteBuffer(resized);

        int[] outputShape = interpreter.getOutputTensor(0).shape();
        List<Detection> results;

        if (isEndToEnd) {
            // Bentuk umum: (1, N, 6) -> N deteksi, tiap baris [x1,y1,x2,y2,conf,class]
            int numDetections = outputShape[1];
            int numAttributes = outputShape[2];
            float[][][] output = new float[1][numDetections][numAttributes];
            interpreter.run(inputBuffer, output);
            results = parseEndToEndOutput(output, bitmap.getWidth(), bitmap.getHeight());
        } else {
            // Bisa channel-first (1, 6, N) atau channel-last (1, N, 6) tergantung
            // hasil konversi model. Dimensi terkecil (biasanya 4+jumlah kelas)
            // dianggap sebagai sumbu atribut, dimensi lain sebagai sumbu anchor.
            int dim1 = outputShape[1];
            int dim2 = outputShape[2];
            boolean channelFirst = dim1 < dim2;
            float[][][] output = new float[1][dim1][dim2];
            interpreter.run(inputBuffer, output);
            results = parseRawOutput(output, bitmap.getWidth(), bitmap.getHeight(), channelFirst);
        }

        lastInferenceTimeMs = SystemClock.elapsedRealtime() - startTime;
        return results;
    }

    private ByteBuffer bitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3);
        buffer.order(ByteOrder.nativeOrder());
        int[] pixels = new int[INPUT_SIZE * INPUT_SIZE];
        bitmap.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE);
        for (int pixel : pixels) {
            buffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            buffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            buffer.putFloat((pixel & 0xFF) / 255.0f);
        }
        buffer.rewind();
        return buffer;
    }

    private List<Detection> parseEndToEndOutput(float[][][] output, int origW, int origH) {
        List<Detection> detections = new ArrayList<>();
        int numDetections = output[0].length;

        for (int i = 0; i < numDetections; i++) {
            float x1 = output[0][i][0];
            float y1 = output[0][i][1];
            float x2 = output[0][i][2];
            float y2 = output[0][i][3];
            float confidence = output[0][i][4];
            int classId = (int) output[0][i][5];

            if (confidence < CONF_THRESHOLD) continue;

            RectF box = scaleBox(x1, y1, x2, y2, origW, origH);
            String label = classId >= 0 && classId < labels.size() ? labels.get(classId) : "unknown";
            detections.add(new Detection(label, confidence, box));
        }

        detections.sort((a, b) -> Float.compare(b.confidence, a.confidence));

        if (!detections.isEmpty()) {
            Detection top = detections.get(0);
            Log.d(TAG, "Hasil final terpilih -> label: \"" + top.label + "\", confidence: " + top.confidence
                    + " (dari " + detections.size() + " deteksi)");
        }

        return detections;
    }

    private List<Detection> parseRawOutput(float[][][] output, int origW, int origH, boolean channelFirst) {
        List<Detection> candidates = new ArrayList<>();
        int numClasses = labels.size();
        int numAnchors = channelFirst ? output[0][0].length : output[0].length;
        float maxScoreSeen = 0f;

        for (int i = 0; i < numAnchors; i++) {
            float cx, cy, w, h;
            float bestScore = 0f;
            int bestClass = -1;

            if (channelFirst) {
                cx = output[0][0][i];
                cy = output[0][1][i];
                w = output[0][2][i];
                h = output[0][3][i];
                for (int c = 0; c < numClasses; c++) {
                    float score = output[0][4 + c][i];
                    if (score > bestScore) {
                        bestScore = score;
                        bestClass = c;
                    }
                }
            } else {
                cx = output[0][i][0];
                cy = output[0][i][1];
                w = output[0][i][2];
                h = output[0][i][3];
                for (int c = 0; c < numClasses; c++) {
                    float score = output[0][i][4 + c];
                    if (score > bestScore) {
                        bestScore = score;
                        bestClass = c;
                    }
                }
            }

            if (bestScore > maxScoreSeen) maxScoreSeen = bestScore;
            if (bestClass == -1 || bestScore < CONF_THRESHOLD) continue;

            float x1 = cx - w / 2f;
            float y1 = cy - h / 2f;
            float x2 = cx + w / 2f;
            float y2 = cy + h / 2f;

            RectF box = scaleBox(x1, y1, x2, y2, origW, origH);
            candidates.add(new Detection(labels.get(bestClass), bestScore, box));
        }

        Log.d(TAG, "parseRawOutput: confidence tertinggi yang ditemukan di semua anchor = "
                + maxScoreSeen + " (threshold = " + CONF_THRESHOLD + "), kandidat lolos threshold = "
                + candidates.size());

        List<Detection> afterNms = nonMaxSuppression(candidates, IOU_THRESHOLD);
        afterNms.sort((a, b) -> Float.compare(b.confidence, a.confidence));

        if (!afterNms.isEmpty()) {
            Detection top = afterNms.get(0);
            Log.d(TAG, "Hasil final terpilih -> label: \"" + top.label + "\", confidence: " + top.confidence
                    + " (dari " + afterNms.size() + " deteksi setelah NMS)");
        }

        return afterNms;
    }

    private RectF scaleBox(float x1, float y1, float x2, float y2, int origW, int origH) {
        float scaleX = origW / (float) INPUT_SIZE;
        float scaleY = origH / (float) INPUT_SIZE;
        return new RectF(x1 * scaleX, y1 * scaleY, x2 * scaleX, y2 * scaleY);
    }

    private List<Detection> nonMaxSuppression(List<Detection> boxes, float iouThreshold) {
        List<Detection> sorted = new ArrayList<>(boxes);
        sorted.sort((a, b) -> Float.compare(b.confidence, a.confidence));
        List<Detection> selected = new ArrayList<>();

        while (!sorted.isEmpty()) {
            Detection best = sorted.remove(0);
            selected.add(best);
            sorted.removeIf(d -> iou(best.box, d.box) > iouThreshold);
        }
        return selected;
    }

    private float iou(RectF a, RectF b) {
        float interLeft = Math.max(a.left, b.left);
        float interTop = Math.max(a.top, b.top);
        float interRight = Math.min(a.right, b.right);
        float interBottom = Math.min(a.bottom, b.bottom);

        float interArea = Math.max(0, interRight - interLeft) * Math.max(0, interBottom - interTop);
        float unionArea = areaOf(a) + areaOf(b) - interArea;
        return unionArea <= 0 ? 0 : interArea / unionArea;
    }

    private float areaOf(RectF r) {
        return Math.max(0, r.right - r.left) * Math.max(0, r.bottom - r.top);
    }

    public void close() {
        interpreter.close();
    }
}
