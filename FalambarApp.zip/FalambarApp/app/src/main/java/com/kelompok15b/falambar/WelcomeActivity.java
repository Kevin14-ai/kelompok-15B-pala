package com.kelompok15b.falambar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Halaman pembuka (Welcome Screen) aplikasi Falambar App.
 */
public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Button btnMulai = findViewById(R.id.btnMulai);
        btnMulai.setOnClickListener(v ->
                startActivity(new Intent(WelcomeActivity.this, MenuActivity.class)));
    }
}
